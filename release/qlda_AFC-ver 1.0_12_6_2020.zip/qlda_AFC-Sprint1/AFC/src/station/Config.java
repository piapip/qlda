package station;

public class Config {
	public static final int A = 1;
	public static final int B = 2;
	public static final int C = 3;
}
