package controller;

public class Config {
	public static final double BASED_FARE = 1.9;
	public static final double BASED_DISTANCE = 5.0;
	public static final double DEFAULT_ADDITION_DISTANCE = 2.0;
	//0.4euro for every extra 2 km, only round up.
	public static final double ADDITIONAL_FARE = 0.4;
}
